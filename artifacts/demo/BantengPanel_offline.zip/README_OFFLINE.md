# BantengPanel offline

Jalankan `python -m http.server 8000` dari folder ini, lalu buka http://localhost:8000/apps/dashboard/ . Tidak perlu data mentah atau internet. Diagram, metrik, PDF dan video adalah artefak riset; tidak memverifikasi kemurnian ternak.
